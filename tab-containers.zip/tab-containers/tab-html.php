<div class="container-tabs">
    <div class="container-tab" data-tab="1">Tổng quan</div>
    <div class="container-tab" data-tab="2">Dịch vụ</div>
    <div class="container-tab" data-tab="3">Đặt lịch</div>
    <div class="container-tab" data-tab="4">Chi phí</div>
    <div class="container-tab" data-tab="5">Kỹ thuật</div>
</div>

<div class="tab-content" data-content="1">Nội dung cho Container 1</div>
<div class="tab-content" data-content="2">Nội dung cho Container 2</div>
<div class="tab-content" data-content="3">Nội dung cho Container 3</div>
<div class="tab-content" data-content="4">Nội dung cho Container 4</div>
<div class="tab-content" data-content="5">Nội dung cho Container 5</div>
